CREATE DATABASE IF NOT EXISTS dockerdb;

USE dockerdb;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(50)
);

INSERT INTO users(name) VALUES
('Alice'),
('Bob'),
('Charlie');