# Docker Learning Project

This project demonstrates:

- Docker containers
- Docker images
- Dockerfile
- Docker Compose
- Environment variables
- Multi-container architecture

Architecture

Client -> Backend (Node.js) -> MySQL

-------------------------------------------------

Prerequisites

Install Docker and Docker Compose

Verify installation

docker --version
docker compose version

-------------------------------------------------

Run Project

1. Open terminal
2. Navigate to project folder
3. Run

docker compose up --build

-------------------------------------------------

Test API

Open browser

http://localhost:5000

Fetch users

http://localhost:5000/users

-------------------------------------------------

Stop containers

docker compose down

Remove volumes

docker compose down -v