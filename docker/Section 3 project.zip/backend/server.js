/*
Simple Express API

Purpose:
- Demonstrate Docker container running a backend service
- Connect to MySQL container using Docker network
*/

const express = require("express");
const mysql = require("mysql2");
require("dotenv").config();

const app = express();

/*
Database connection using environment variables
These values come from backend/.env
*/
const db = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME
});

app.get("/", (req, res) => {
  res.send("Docker Learning Project Running 🚀");
});

app.get("/users", (req, res) => {
  db.query("SELECT * FROM users", (err, result) => {
    if (err) throw err;
    res.json(result);
  });
});

app.listen(process.env.PORT, () => {
  console.log(`Server running on port ${process.env.PORT}`);
});