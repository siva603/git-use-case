# DevOps CI/CD Project (Git → Jenkins → Maven → Docker)

This project demonstrates a **real DevOps pipeline**:

Developer → Git → Jenkins → Maven Build → Docker Image → Run Container

---

## Tools Used
- Git
- Jenkins
- Maven
- Docker
- Java (Spring Boot)

---

# Step 1 — Clone Project
git clone <your-repo-url>
cd devops-maven-docker-jenkins-project

# Step 2 — Build Using Maven
mvn clean package

# Step 3 — Build Docker Image
docker build -t devops-demo .

# Step 4 — Run Docker Container
docker run -p 8080:8080 devops-demo

Open browser:
http://localhost:8080