# Project 1 — Container Data Loss Demo

Purpose:
Demonstrate that data stored inside a container is lost when the container is removed.

Steps:

1 Start containers
docker compose up --build

2 Create user
POST http://localhost:5000/users
Body:
{ "name":"Alice" }

3 Fetch users
GET http://localhost:5000/users

4 Stop container
docker compose down

5 Start again
docker compose up

Now the database will be EMPTY because SQLite file was inside the container filesystem.