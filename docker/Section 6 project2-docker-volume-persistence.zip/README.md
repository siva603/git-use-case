# Project 2 — Docker Volume Persistence Demo

Purpose:
Demonstrate persistent storage using Docker volumes.

Steps

1 Start container
docker compose up --build

2 Create user
POST http://localhost:5001/users

3 Check users
GET http://localhost:5001/users

4 Stop container
docker compose down

5 Start again
docker compose up

Users will still exist because the database file is stored in Docker volume.

Check volumes:
docker volume ls