const express = require("express");
const db = require("./database");

const app = express();
app.use(express.json());

app.post("/users",(req,res)=>{
  const name=req.body.name;
  db.run("INSERT INTO users(name) VALUES(?)",[name],function(err){
    if(err) return res.send(err);
    res.send({message:"User created",id:this.lastID});
  });
});

app.get("/users",(req,res)=>{
  db.all("SELECT * FROM users",(err,rows)=>{
    if(err) return res.send(err);
    res.json(rows);
  });
});

app.listen(5000,()=>{
  console.log("Server running on port 5000");
});