const sqlite3 = require("sqlite3").verbose();

// database stored in mounted volume folder
const db = new sqlite3.Database("/data/data.db");

db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS users(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT
    )
  `);
});

module.exports = db;