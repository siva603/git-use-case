Docker Advanced DevOps Learning Project

Architecture

Client -> Nginx -> Node API -> PostgreSQL
                          -> Redis Cache

Concepts Learned

Docker Images
Docker Containers
Docker Volumes
Docker Networking
Redis Cache
Reverse Proxy (Nginx)
Multi-container apps

Run Project

docker compose up --build

API through nginx

http://localhost:8080

Create user

POST /users
{
"name":"Alice"
}

Fetch users

GET /users

Stop containers

docker compose down

Volume persistence

docker volume ls