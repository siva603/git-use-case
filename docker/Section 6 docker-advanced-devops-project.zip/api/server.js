const express = require("express");
const { Client } = require("pg");
const redis = require("redis");
require("dotenv").config();

const app = express();
app.use(express.json());

const pgClient = new Client({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  port: 5432
});

pgClient.connect();

const redisClient = redis.createClient({
  url: `redis://${process.env.REDIS_HOST}:6379`
});

redisClient.connect();

app.get("/", (req,res)=>{
  res.send("Docker DevOps Project Running");
});

app.post("/users", async (req,res)=>{
  const {name}=req.body;
  const result = await pgClient.query(
    "INSERT INTO users(name) VALUES($1) RETURNING *",
    [name]
  );
  res.json(result.rows[0]);
});

app.get("/users", async (req,res)=>{

  const cache = await redisClient.get("users");

  if(cache){
    return res.json(JSON.parse(cache));
  }

  const result = await pgClient.query("SELECT * FROM users");

  await redisClient.set("users",JSON.stringify(result.rows));

  res.json(result.rows);
});

app.listen(5000,()=>{
  console.log("API running on port 5000");
});