# Kubernetes DevOps Demo Project

This project demonstrates a **complete DevOps flow**:

Developer → Git → Jenkins → Maven Build → Docker Image → Kubernetes Deployment

Technologies used:
- Java (Spring Boot)
- Maven
- Docker
- Jenkins (Declarative Pipeline - Groovy)
- Kubernetes

---

## Project Structure

```
k8s-devops-demo
│
├── Jenkinsfile
├── Dockerfile
├── pom.xml
├── src/main/java/com/example/demo/DemoApplication.java
├── src/main/java/com/example/demo/controller/HelloController.java
│
└── k8s/
    ├── deployment.yaml
    └── service.yaml
```

---

## DevOps Pipeline Flow

Developer pushes code → Git  
↓  
Jenkins Pipeline triggered  
↓  
Maven Build  
↓  
Docker Image Build  
↓  
Push Docker Image to Registry  
↓  
Deploy to Kubernetes  

---

## Jenkins Pipeline Stages

1. Checkout Code
2. Maven Build
3. Build Docker Image
4. Push Docker Image
5. Deploy to Kubernetes

---

## Run Locally

Build project

```
mvn clean package
```

Build docker image

```
docker build -t demo-app:1.0 .
```

Run container

```
docker run -p 8080:8080 demo-app:1.0
```

Access:

```
http://localhost:8080/hello
```

---

## Deploy to Kubernetes

```
kubectl apply -f k8s/deployment.yaml
kubectl apply -f k8s/service.yaml
```

Check pods

```
kubectl get pods
```

Check services

```
kubectl get svc
```

Access using NodePort.

---