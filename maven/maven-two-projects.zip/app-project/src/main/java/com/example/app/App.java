package com.example.app;

import com.example.lib.MessageService;

public class App {

    public static void main(String[] args) {

        MessageService service = new MessageService();

        System.out.println(service.getMessage());

    }

}
