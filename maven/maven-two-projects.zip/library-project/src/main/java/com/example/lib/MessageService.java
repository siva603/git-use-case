package com.example.lib;

public class MessageService {

    public String getMessage() {
        return "Hello from Library Project";
    }

}
