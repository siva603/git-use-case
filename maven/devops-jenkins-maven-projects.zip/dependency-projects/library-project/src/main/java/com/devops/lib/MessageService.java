
package com.devops.lib;

public class MessageService {
 public String message(){
  return "Hello from Library";
 }
}
