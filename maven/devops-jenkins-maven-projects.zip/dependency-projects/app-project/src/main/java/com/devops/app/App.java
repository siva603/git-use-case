
package com.devops.app;

import com.devops.lib.MessageService;

public class App {
 public static void main(String[] args){
  MessageService m=new MessageService();
  System.out.println(m.message());
 }
}
