package com.example.service;

public class CalculatorService {

    public int add(int a, int b) {
        return a + b;
    }

    public int divide(int a, int b) {
        if(b == 0){
            throw new IllegalArgumentException("Division by zero");
        }
        return a / b;
    }

    public boolean isPrime(int number) {
        if(number <= 1) return false;
        for(int i=2;i<=Math.sqrt(number);i++){
            if(number % i == 0) return false;
        }
        return true;
    }

    public String reverse(String text) {
        return new StringBuilder(text).reverse().toString();
    }

    public double calculateDiscount(double price, double percent) {
        if(percent < 0 || percent > 100){
            throw new IllegalArgumentException("Invalid discount");
        }
        return price - (price * percent / 100);
    }
}
