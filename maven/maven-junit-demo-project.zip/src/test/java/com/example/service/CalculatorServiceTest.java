package com.example.service;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CalculatorServiceTest {

    CalculatorService service = new CalculatorService();

    @Test
    void testAdd() {
        assertEquals(5, service.add(2,3));
        assertEquals(0, service.add(-2,2));
    }

    @Test
    void testDivide() {
        assertEquals(2, service.divide(4,2));
    }

    @Test
    void testDivideByZero() {
        Exception ex = assertThrows(IllegalArgumentException.class, () -> {
            service.divide(10,0);
        });
        assertEquals("Division by zero", ex.getMessage());
    }

    @Test
    void testPrimeNumbers() {
        assertTrue(service.isPrime(7));
        assertFalse(service.isPrime(4));
        assertFalse(service.isPrime(1));
    }

    @Test
    void testReverseString() {
        assertEquals("olleh", service.reverse("hello"));
    }

    @Test
    void testDiscountCalculation() {
        assertEquals(90.0, service.calculateDiscount(100,10));
    }

    @Test
    void testInvalidDiscount() {
        assertThrows(IllegalArgumentException.class, () -> {
            service.calculateDiscount(100,150);
        });
    }
}
